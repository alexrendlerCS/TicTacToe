module csc335.TTTdone {
    requires javafx.controls;
    requires java.desktop;
    requires javafx.graphics;
    requires javafx.base;
    exports views;
}
